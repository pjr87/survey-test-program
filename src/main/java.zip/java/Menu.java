
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Scanner;

/*******************************************************************************
 * 2016, All rights reserved.
 *******************************************************************************/

// Start of user code (user defined imports)

// End of user code

/**
 * Description of Menu.
 * 
 * @author phillipryan
 */
public class Menu {
	/**
	 * Description of the property test.
	 */
	private static Test test = null;

	/**
	 * Description of the property survey.
	 */
	private static Survey survey = null;

	// Start of user code (user defined attributes for Menu)

	// End of user code

	/**
	 * The constructor.
	 */
	public Menu() {
		// Start of user code constructor for Menu)
		super();
		// End of user code
	}

	/**
	 * Description of the method main.
	 * @param args 
	 */
	public static void main(String args[]){
		// Start of user code for method main
		// End of user code
		DisplayMenu();
	}

	/**
	 * Description of the method SurveyMenu.
	 */
	public static void DisplayMenu() {
		while(true){
			outputMenu1();
			int choice = getInput();
			if( choice == 1 ){
				survey = new Survey();
				survey.isTest = false;
				outputMenu2("Survey");
			}
			else if( choice == 2 ){
				test = new Test();
				test.isTest = true;
				outputMenu2("Test");
			}
			else{
				System.out.println("Error invalid choice");
			}
		}
	}
	
	public static int getInput(){
		Scanner reader = new Scanner(System.in); 
		int choice = reader.nextInt(); 
		return choice;
	}
	
	public static void outputMenu1(){
		System.out.println("1) Survey");
		System.out.println("2) Test");
	}
	
	public static void outputMenu2(String type){
		while(true){
			System.out.println("1) Create a " + type);
			System.out.println("2) Display a " + type);
			System.out.println("3) Load a " + type);
			System.out.println("4) Save a " + type);
			System.out.println("5) Quit");
			
			int choice = getInput();
			if(choice == 1){
				
				if( type.equals("Survey")){
					System.out.println("Creating survey");
					survey.Create();
				}
				else{
					System.out.println("Creating test");
					test.Create();
				}
			}
			else if( choice == 2 ){
				System.out.println("Display");
				if( type.equals("Survey")){
					survey.Display();
				}
				else{
					test.Display();
				}
			}
			else if( choice == 3 ){
				System.out.println("Please select a file to load");
				File dir = new File(".");
				List<String> Files = new ArrayList<String>();
				int i = 1;
				for (File file : dir.listFiles()) {
					if (file.getName().endsWith((".ser"))){
						System.out.println(i + ") " + file.getName());
						Files.add(file.getName());
						i++;
					}
				}
				int file = getInput();
				System.out.println("Loading " + Files.get(file-1));
				if(Files.get(file-1).contains("Survey")){
					survey = (Survey) Load(Files.get(file-1));
				}
				else{
					test = (Test) Load(Files.get(file-1));
				}
			}
			else if( choice == 4 ){
				System.out.println("Save");
				Calendar cal = Calendar.getInstance();
		        SimpleDateFormat sdf = new SimpleDateFormat("HHmmss");
		        System.out.println(  );
				if(type.equals("Survey")){
					Save(survey, "Survey" + sdf.format(cal.getTime()) + ".ser");
				}
				else{
					Save(test, "Test" + sdf.format(cal.getTime()) + ".ser");
				}
			}
			else if( choice == 5 ){
				System.out.println("Quit");
				break;
			}
			else{
				System.out.println("Error invalid response");
			}
		}
	}
	
	/**
	 * Description of the method Load.
	 * @param filename 
	 */
	public static Object Load(String filename) {
		FileInputStream input;
		Object object = null;
		try {
			input = new FileInputStream(filename);
	        ObjectInputStream output = new ObjectInputStream(input);
	        object = output.readObject();
	        output.close();
		} catch (IOException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return object;
	}

	/**
	 * Description of the method Save.
	 * @param object 
	 * @param filename 
	 */
	public static void Save(Object object, String filename) {
		FileOutputStream output;
		try {
			output = new FileOutputStream(filename);
	        ObjectOutputStream oos = new ObjectOutputStream(output);
	        oos.writeObject(object);
	 
	        output.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// Start of user code (user defined methods for Menu)

	// End of user code
	/**
	 * Returns test.
	 * @return test 
	 */
	public Test getTest() {
		return this.test;
	}

	/**
	 * Sets a value to attribute test. 
	 * @param newTest 
	 */
	public void setTest(Test newTest) {
		this.test = newTest;
	}

	/**
	 * Returns survey.
	 * @return survey 
	 */
	public Survey getSurvey() {
		return this.survey;
	}

	/**
	 * Sets a value to attribute survey. 
	 * @param newSurvey 
	 */
	public void setSurvey(Survey newSurvey) {
		this.survey = newSurvey;
	}

}
