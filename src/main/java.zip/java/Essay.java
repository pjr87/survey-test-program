import java.util.ArrayList;
import java.util.List;

/*******************************************************************************
 * 2016, All rights reserved.
 *******************************************************************************/

// Start of user code (user defined imports)

// End of user code

/**
 * Description of Essay.
 * 
 * @author phillipryan
 */
public class Essay extends Question {

	/**
	 * Description of the property userName.
	 */
	protected String userName = "";
	
	/**
	 * Description of the property response.
	 */
	//protected Car response;
	
	/**
	 * Description of the property prompt.
	 */
	protected static String prompt = "";

	/**
	 * Description of the method Create.
	 */
	public void Create() {
		System.out.println("Enter the prompt for your Essay question");
		String Prompt = Survey.getInputString();
		prompt = Prompt;
		StringCar stringCar = new StringCar();
		response = stringCar;
	}

	/**
	 * Description of the method Display.
	 */
	public void Display() {
		System.out.println(this.prompt);
	}

	/**
	 * Description of the method Edit.
	 */
	public void Edit() {
		// Start of user code for method Edit
		// End of user code
	}

	/**
	 * Description of the method Take.
	 */
	public void Take() {
		// Start of user code for method Take
		// End of user code
	}

	// Start of user code (user defined methods for Essay)

	// End of user code

	/**
	 * Description of Matching.
	 * 
	 * @author phillipryan
	 */
	public class Matching {
		// Start of user code (user defined attributes for Matching)

		// End of user code

		/**
		 * The constructor.
		 */
		public Matching() {
			// Start of user code constructor for Matching)
			super();
			// End of user code
		}

		/**
		 * Description of the method Create.
		 */
		public void Create() {
			// Start of user code for method Create
			// End of user code
		}

		/**
		 * Description of the method Display.
		 */
		public void Display() {
			// Start of user code for method Display
			// End of user code
		}

		// Start of user code (user defined methods for Matching)

		// End of user code

	}

}
