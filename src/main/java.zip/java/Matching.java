import java.util.ArrayList;
import java.util.List;

/*******************************************************************************
 * 2016, All rights reserved.
 *******************************************************************************/

// Start of user code (user defined imports)

// End of user code

/**
 * Description of Matching.
 * 
 * @author phillipryan
 */
public class Matching extends Question {
	
	/**
	 * Description of the property userName.
	 */
	protected String userName = "";
	
	/**
	 * Description of the property response.
	 */
	//protected Car response;
	
	/**
	 * Description of the property prompt.
	 */
	protected static String prompt = "";

	/**
	 * Description of the method Create.
	 */
	public void Create() {
		System.out.println("Enter the prompt for your Matching question");
		String Prompt = Survey.getInputString();
		prompt = Prompt;
		
		System.out.println("Enter the number of choices:");
		int num = Survey.getInput();
		
		for(int i=0; i<num; i++){
			StringCar stringCar = new StringCar();
			
			System.out.println("Enter choice");
			String Choice = Survey.getInputString();
			stringCar.setChoices(Choice);
			
			if(Survey.isTest){
				System.out.println("Enter number this choice matches with:");
				int Correct = Survey.getInput();
				stringCar.setCorrectAnswer(String.valueOf(Correct));
			}
			
			response = stringCar;
		}
	}

	/**
	 * Description of the method Display.
	 */
	public void Display() {
		System.out.println(this.prompt);
	}

	/**
	 * Description of the method Edit.
	 */
	public void Edit() {
		// Start of user code for method Edit
		// End of user code
	}

	/**
	 * Description of the method Take.
	 */
	public void Take() {
		// Start of user code for method Take
		// End of user code
	}

}
