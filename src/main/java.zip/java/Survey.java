/*******************************************************************************
 * 2016, All rights reserved.
 *******************************************************************************/


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
// Start of user code (user defined imports)
import java.util.Scanner;

// End of user code

/**
 * Description of Survey.
 * 
 * @author phillipryan
 */
public class Survey implements Serializable {
	/**
	 * Description of the property userName.
	 */
	protected String userName = "";

	/**
	 * Description of the property questions.
	 */
	protected List<Question> questions = new ArrayList<Question>();
	
	/**
	 * Description of the property isTest.
	 */
	protected static Boolean isTest = Boolean.FALSE;
	
	// Start of user code (user defined attributes for Survey)
	
	// End of user code
	
	
	/**
	 * Description of the method Create.
	 */
	public void Create() {
		while(true){
			System.out.println("1) Add a new T/F question");
			System.out.println("2) Add a new multiple choice question");
			System.out.println("3) Add a new short answer question");
			System.out.println("4) Add a new essay question");
			System.out.println("5) Add a new ranking question");
			System.out.println("6) Add a new matching question");
			System.out.println("7) Quit");
			
			int tmpchoice = getInput();
			if(tmpchoice == 1){
				System.out.println("T/F");
				TrueFalse tf = new TrueFalse();
				tf.Create();
				questions.add(tf);
			}
			if(tmpchoice == 2){
				System.out.println("multiple choice");
				MultipleChoice mc = new MultipleChoice();
				mc.Create();
				questions.add(mc);
			}
			if(tmpchoice == 3){
				System.out.println("short answer");
				ShortAnswer sa = new ShortAnswer();
				sa.Create();
				questions.add(sa);
			}
			if(tmpchoice == 4){
				System.out.println("essay");
				Essay es = new Essay();
				es.Create();
				questions.add(es);
			}
			if(tmpchoice == 5){
				System.out.println("ranking");
				Rank ra = new Rank();
				ra.Create();
				questions.add(ra);
			}
			if(tmpchoice == 6){
				System.out.println("matching");
				Matching ma = new Matching();
				ma.Create();
				questions.add(ma);
			}
			if(tmpchoice == 7){
				System.out.println("quit");
				break;
			}
		}
	}
	
	public static int getInput(){
		Scanner reader = new Scanner(System.in); 
		int choice = reader.nextInt(); 
		return choice;
	}
	
	public static String getInputString(){
		Scanner reader = new Scanner(System.in); 
		String choice = reader.nextLine();
		return choice;
	}
	
	/**
	 * Description of the method Display.
	 */
	public void Display() {
		for(int i = 0 ; i < questions.size() ; i++){
			 System.out.print(i+1 + ") ");
			 questions.get(i).Display();
			 
			 if(this.isTest){
				 Question tmp =  questions.get(i);
				 Car tmpcar = tmp.getResponse();
				 tmpcar.getCA();
			 }
		}
	}
	 
	/**
	 * Description of the method Take.
	 */
	public void Take() {
		// Start of user code for method Take
		// End of user code
	}
	 
	/**
	 * Description of the method Delete.
	 */
	public void Delete() {
		// Start of user code for method Delete
		// End of user code
	}
	 
	/**
	 * Description of the method Tabulate.
	 */
	public void Tabulate() {
		// Start of user code for method Tabulate
		// End of user code
	}
	 
	/**
	 * Description of the method Edit.
	 */
	public void Edit() {
		// Start of user code for method Edit
		// End of user code
	}
	 
	// Start of user code (user defined methods for Survey)
	
	// End of user code
	/**
	 * Returns userName.
	 * @return userName 
	 */
	public String getUserName() {
		return this.userName;
	}
	
	/**
	 * Sets a value to attribute userName. 
	 * @param newUserName 
	 */
	public void setUserName(String newUserName) {
	    this.userName = newUserName;
	}

	/**
	 * Returns questions.
	 * @return questions 
	 */
	public List<Question> getQuestions() {
		return this.questions;
	}

	/**
	 * Returns isTest.
	 * @return isTest 
	 */
	public Boolean getIsTest() {
		return this.isTest;
	}
	
	/**
	 * Sets a value to attribute isTest. 
	 * @param newIsTest 
	 */
	public void setIsTest(Boolean newIsTest) {
	    this.isTest = newIsTest;
	}



}
