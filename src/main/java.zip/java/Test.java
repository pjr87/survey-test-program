import java.io.Serializable;
import java.util.Scanner;

/*******************************************************************************
 * 2016, All rights reserved.
 *******************************************************************************/


// Start of user code (user defined imports)

// End of user code

/**
 * Description of Test.
 * 
 * @author phillipryan
 */
public class Test extends Survey implements Serializable{
	// Start of user code (user defined attributes for Test)
	
	// End of user code
	
	
	/**
	 * Description of the method Grade.
	 */
	public void Grade() {
		// Start of user code for method Grade
		// End of user code
	}
	 
	/**
	 * Description of the method Edit.
	 */
	public void Edit() {
		// Start of user code for method Edit
		// End of user code
	}
	 
	// Start of user code (user defined methods for Test)
	
	// End of user code


}
