import java.io.Serializable;
import java.util.List;

/*******************************************************************************
 * 2016, All rights reserved.
 *******************************************************************************/

// Start of user code (user defined imports)

// End of user code

/**
 * Description of Car.
 * 
 * @author phillipryan
 */
public abstract class Car implements Serializable{
	// Start of user code (user defined attributes for Car)

	// End of user code

	/**
	 * The constructor.
	 */
	public Car() {
		// Start of user code constructor for Car)
		super();
		// End of user code
	}

	/**
	 * Description of the method Grade.
	 * @return 
	 */
	public Boolean Grade() {
		// Start of user code for method Grade
		Boolean Grade = Boolean.FALSE;
		return Grade;
		// End of user code
	}

	/**
	 * Description of the method getResponse.
	 * @return 
	 */
	public String getResponse() {
		// Start of user code for method getResponse
		String getResponse = "";
		return getResponse;
		// End of user code
	}
	
	public void getCA(){
		
	}

	/**
	 * Description of the method VerifyUserResponse.
	 * @return 
	 */
	public Boolean VerifyUserResponse() {
		// Start of user code for method VerifyUserResponse
		Boolean VerifyUserResponse = Boolean.FALSE;
		return VerifyUserResponse;
		// End of user code
	}

	/**
	 * Description of the method setCorrectAnswer.
	 */
	public void setCorrectAnswer() {
		// Start of user code for method setCorrectAnswer
		// End of user code
	}

	/**
	 * Description of the method setChoices.
	 */
	public void setChoices() {
		// Start of user code for method setChoices
		// End of user code
	}

	// Start of user code (user defined methods for Car)

	// End of user code

}
