/*******************************************************************************
 * 2016, All rights reserved.
 *******************************************************************************/


import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
// Start of user code (user defined imports)

// End of user code

/**
 * Description of Question.
 * 
 * @author phillipryan
 */
public abstract class Question implements Serializable{
	
	/**
	 * Description of the property userName.
	 */
	protected String userName = "";
	
	/**
	 * Description of the property response.
	 */
	protected Car response;
	
	/**
	 * Description of the property prompt.
	 */
	protected static String prompt = "";
	
	// Start of user code (user defined attributes for Question)
	
	// End of user code
	
	/**
	 * The constructor.
	 */
	public Question() {
		// Start of user code constructor for Question)
		super();
		// End of user code
	}
	
	/**
	 * Description of the method Create.
	 */
	public void Create() {
		// Start of user code for method Create
		// End of user code
	}
	 
	/**
	 * Description of the method Display.
	 */
	public void Display() {
		// Start of user code for method Display
		// End of user code
	}
	 
	/**
	 * Description of the method Take.
	 */
	public void Take() {
		// Start of user code for method Take
		// End of user code
	}
	 
	/**
	 * Description of the method Edit.
	 */
	public void Edit() {
		// Start of user code for method Edit
		// End of user code
	}
	 
	// Start of user code (user defined methods for Question)


	/**
	 * Returns userName.
	 * @return userName 
	 */
	public String getUserName() {
		return this.userName;
	}
	
	/**
	 * Sets a value to attribute userName. 
	 * @param newUserName 
	 */
	public void setUserName(String newUserName) {
	    this.userName = newUserName;
	}

	/**
	 * Returns response.
	 * @return response 
	 */
	public Car getResponse() {
		return this.response;
	}

	/**
	 * Returns prompt.
	 * @return prompt 
	 */
	public String getPrompt() {
		return this.prompt;
	}
	
	/**
	 * Sets a value to attribute prompt. 
	 * @param newPrompt 
	 */
	public void setPrompt(String newPrompt) {
	    this.prompt = newPrompt;
	}



}
