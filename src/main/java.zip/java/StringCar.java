/*******************************************************************************
 * 2016, All rights reserved.
 *******************************************************************************/


import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
// Start of user code (user defined imports)

// End of user code

/**
 * Description of StringCar.
 * 
 * @author phillipryan
 */
public class StringCar extends Car {
	/**
	 * Description of the property userResponse.
	 */
	protected List<String> userResponse = new ArrayList<String>();
	
	/**
	 * Description of the property correctAnswer.
	 */
	protected List<String> correctAnswer = new ArrayList<String>();
	
	/**
	 * Description of the property choice.
	 */
	protected List<String> choice = new ArrayList<String>();
	
	// Start of user code (user defined attributes for StringCar)
	
	// End of user code
	
	
	/**
	 * Description of the method Grade.
	 * @return 
	 */
	public Boolean Grade() {
		// Start of user code for method Grade
		// End of user code
		return false;
	}
	 
	/**
	 * Description of the method getResponse.
	 * @return 
	 */
	public String getResponse() {
		// Start of user code for method getResponse
		String getResponse = "";
		return getResponse;
		// End of user code
	}
	 
	/**
	 * Description of the method VerifyUserResponse.
	 * @return 
	 */
	public Boolean VerifyUserResponse() {
		// Start of user code for method VerifyUserResponse
		Boolean VerifyUserResponse = Boolean.FALSE;
		return VerifyUserResponse;
		// End of user code
	}
	 
	/**
	 * Description of the method setCorrectAnswer.
	 */
	public void setCorrectAnswer(String CA) {
		this.correctAnswer.add(CA);
	}
	 
	/**
	 * Description of the method setChoices.
	 * @param choice 
	 */
	public void setChoices(String Choice) {
		this.choice.add(Choice);
	}
	
	public void getCA(){
		if(correctAnswer.size() == 1){
			System.out.println("The correct answer is: " + correctAnswer.get(0));
		}
		else{
			System.out.println("The correct answer is: ");
			for(int i=0; i<correctAnswer.size(); i++){
				System.out.print(correctAnswer + ", ");
			}
		}
			
	}
	 
	// Start of user code (user defined methods for StringCar)
	
	// End of user code
	/**
	 * Returns userResponse.
	 * @return userResponse 
	 */
	public List<String> getUserResponse() {
		return this.userResponse;
	}

	/**
	 * Returns correctAnswer.
	 * @return correctAnswer 
	 */
	public List<String> getCorrectAnswer() {
		return this.correctAnswer;
	}

	/**
	 * Returns choice.
	 * @return choice 
	 */
	public List<String> getChoice() {
		return this.choice;
	}



}
